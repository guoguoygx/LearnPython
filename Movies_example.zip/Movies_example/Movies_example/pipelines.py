# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from openpyxl import Workbook

class MoviesExamplePipeline(object):
    def process_item(self, item, spider):
        return item
class SqlTablePipeline(object):
    import pymssql
    server = "172.18.204.34"  # 连接服务器地址
    user = "sa"  # 连接帐号
    password = "05597895110ygx"  # 连接密码
    conn = pymssql.connect(server, user, password, "yuguoxiao")  # 获取连接
    cursor = conn.cursor()  # 获取光标
    def __init__(self):
        # 创建表
        self.cursor.execute("""
            IF OBJECT_ID('Moviess','U')IS NOT NULL
                DROP TABLE Moviess
            CREATE TABLE Moviess (
                Movietype VARCHAR(max) NOT NULL,
                Moviename VARCHAR(max) NOT NULL,
                ImageUrl VARCHAR(max),
                MovieIntroduce VARCHAR(max),
                DownloadUrl VARCHAR(max)
            )
            """)
    def process_item(self, item, spider):
        # 插入获得的数据
        self.cursor.executemany(
            "INSERT INTO Moviess VALUES (%s, %s, %s,%s,%s)",
            [(item['movietype'],item['moviename'],item['moviepicture'],item['movieinformation']
              ,item['mvurl'])])
        # 你必须调用 commit() 来保持你数据的提交如果你没有将自动提交设置为true
        self.conn.commit()
        return item
    def close_spider(self, spider):
        self.conn.close()
