#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
# @Time : 2018\10\30 0030 13:12 
# @Author : Aries 
# @Site :  
# @File : begin.py 
# @Software: PyCharm
from scrapy import cmdline
cmdline.execute(['scrapy','crawl','movies'])
